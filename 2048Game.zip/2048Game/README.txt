- Click 2048Game.jar file to play game
!!! If doesn't work, install Java with JavaSetup8u211.exe file